# alfo-admin-cookbook

http://www.mattboldt.com/aws-opsworks-rails-chef-12/


```
berks install
berks package dist/cookbooks.IDX.tar.gz
```