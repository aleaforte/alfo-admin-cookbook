Author and Contributors
=======================

Author
------

`Igor Rzegocki`_ (`@ajgon`_)

Contributors
------------

* Nick Marden (`@nickmarden`_)
* Phong Si (`@phongsi`_)
* Kevin Pheasey (`@kpheasey`_)
* Nathan Flood (`@npflood`_)
* Teruo Adachi (`@interu`_)
* Marcos Beirigo (`@marcosbeirigo`_)

.. _Igor Rzegocki: https://www.rzegocki.pl/
.. _@ajgon: https://github.com/ajgon
.. _@nickmarden: https://github.com/nickmarden
.. _@phongsi: https://github.com/phongsi
.. _@kpheasey: https://github.com/kpheasey
.. _@npflood: https://github.com/npflood
.. _@interu: https://github.com/interu
.. _@marcosbeirigo: https://github.com/marcosbeirigo
