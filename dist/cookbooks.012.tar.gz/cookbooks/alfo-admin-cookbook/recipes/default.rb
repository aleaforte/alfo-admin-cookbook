#
# Cookbook:: alfo-admin-cookbook
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.

node.default['packages-cookbook'] = [
 'libpq-dev',
 'nodejs',
 'zsh',
]