# alfo-admin-cookbook

http://www.mattboldt.com/aws-opsworks-rails-chef-12/


```
berks install
berks package dist/cookbooks.IDX.tar.gz
```

If pointing to the same "version" on a different repo / branch, you will need 
`berks update cookbook_name` instead of `berks install`
