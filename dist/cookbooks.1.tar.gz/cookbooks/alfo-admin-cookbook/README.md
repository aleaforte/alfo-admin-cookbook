# alfo-admin-cookbook

http://www.mattboldt.com/aws-opsworks-rails-chef-12/

